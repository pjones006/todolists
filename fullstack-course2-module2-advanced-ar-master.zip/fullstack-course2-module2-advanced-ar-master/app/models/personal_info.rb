class PersonalInfo < ActiveRecord::Base
  belongs_to :person
end
