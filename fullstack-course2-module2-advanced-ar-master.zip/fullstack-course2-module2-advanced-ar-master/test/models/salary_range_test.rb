require 'test_helper'

class SalaryRangeTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
