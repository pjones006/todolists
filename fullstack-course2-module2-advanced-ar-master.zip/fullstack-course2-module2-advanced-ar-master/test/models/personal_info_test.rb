require 'test_helper'

class PersonalInfoTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
